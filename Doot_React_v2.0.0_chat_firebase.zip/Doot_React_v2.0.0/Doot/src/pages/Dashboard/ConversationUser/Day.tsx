import React from "react";

const Day = () => {
  return (
    <li className="chat-list">
      <div className="chat-day-title">
        <span className="title">Today</span>
      </div>
    </li>
  );
};

export default Day;
