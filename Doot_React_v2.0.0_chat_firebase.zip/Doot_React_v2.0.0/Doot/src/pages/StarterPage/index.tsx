import React from "react";

interface IndexProps {}
const Index = (props: IndexProps) => {
  return <div></div>;
};

export default Index;
